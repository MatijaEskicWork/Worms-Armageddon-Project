var searchData=
[
  ['event',['Event',['../types_shorter_8h.html#a968dbade547d18c0fc972caf39d984e8',1,'typesShorter.h']]]
];
