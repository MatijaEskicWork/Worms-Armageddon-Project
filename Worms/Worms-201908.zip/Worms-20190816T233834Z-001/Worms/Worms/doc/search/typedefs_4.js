var searchData=
[
  ['window',['Window',['../types_shorter_8h.html#ad85d988c6435100855b98e010ffff6b8',1,'typesShorter.h']]]
];
