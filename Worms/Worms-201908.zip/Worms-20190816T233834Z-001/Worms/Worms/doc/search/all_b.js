var searchData=
[
  ['name',['name',['../struct_high_score.html#a282b88b1839c7993be51c2d1678ce5d9',1,'HighScore::name()'],['../struct_worm.html#a9997d8ee2df51d18efed254a5aa016fd',1,'Worm::name()']]]
];
