var searchData=
[
  ['updatehighscores',['UpdateHighScores',['../high_scores_8c.html#aa9ad9063961454218812e89a854fa980',1,'UpdateHighScores(char *name, int score):&#160;highScores.c'],['../high_scores_8h.html#a37dd451af3218cf6188acc1227f71f46',1,'UpdateHighScores(char *, int):&#160;highScores.c']]],
  ['updatemap',['UpdateMap',['../map_8c.html#a80c3453f53953e460aaeff7557c5bea1',1,'UpdateMap(Renderer render):&#160;map.c'],['../map_8h.html#a80c3453f53953e460aaeff7557c5bea1',1,'UpdateMap(Renderer render):&#160;map.c']]],
  ['updatewormmove',['UpdateWormMove',['../game_8c.html#af0ef0d0fb99349d4386beaf89fc6675d',1,'UpdateWormMove(struct Map map, struct Worm worm, Renderer render, SDL_Rect curr_pos, struct Worm *wormx):&#160;game.c'],['../game_8h.html#af0ef0d0fb99349d4386beaf89fc6675d',1,'UpdateWormMove(struct Map map, struct Worm worm, Renderer render, SDL_Rect curr_pos, struct Worm *wormx):&#160;game.c']]]
];
