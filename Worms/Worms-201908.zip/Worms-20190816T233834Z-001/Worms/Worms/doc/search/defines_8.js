var searchData=
[
  ['width',['Width',['../init_create_8h.html#aed8fadf7b3e976964bffdbc43a3b9402',1,'initCreate.h']]]
];
