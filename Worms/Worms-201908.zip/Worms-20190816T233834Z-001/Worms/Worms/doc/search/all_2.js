var searchData=
[
  ['checkbounds',['CheckBounds',['../game_8c.html#a468e6bee1a546cf14c4729cd44d9597f',1,'CheckBounds(SDL_Rect position, int x_coord, int choice):&#160;game.c'],['../game_8h.html#a468e6bee1a546cf14c4729cd44d9597f',1,'CheckBounds(SDL_Rect position, int x_coord, int choice):&#160;game.c']]],
  ['checkifhover',['CheckIfHover',['../making_menu_8c.html#afc43a28ca87591786836417e88f766a8',1,'CheckIfHover(SDL_Rect position):&#160;makingMenu.c'],['../making_menu_8h.html#afc43a28ca87591786836417e88f766a8',1,'CheckIfHover(SDL_Rect position):&#160;makingMenu.c']]],
  ['coeff',['coeff',['../struct_saved_worm.html#a289789fb674ef8a44ecd4a8c8a6d1fa8',1,'SavedWorm::coeff()'],['../struct_worm.html#a289789fb674ef8a44ecd4a8c8a6d1fa8',1,'Worm::coeff()']]],
  ['continue_2ec',['continue.c',['../continue_8c.html',1,'']]],
  ['continue_2eh',['continue.h',['../continue_8h.html',1,'']]],
  ['continuegame',['ContinueGame',['../continue_8c.html#a8143811ac0318e494fa7e8f923835d76',1,'ContinueGame(struct Worm **worm1, struct Worm **worm2, struct Map **map):&#160;continue.c'],['../continue_8h.html#a8143811ac0318e494fa7e8f923835d76',1,'ContinueGame(struct Worm **worm1, struct Worm **worm2, struct Map **map):&#160;continue.c']]],
  ['continuegame1',['ContinueGame1',['../game_mode_8c.html#afdfdd17d5049e9f133ace40b2d07d735',1,'ContinueGame1(struct Worm *worm1, struct Worm *worm2, struct Map *map, Renderer render, Window window):&#160;gameMode.c'],['../game_mode_8h.html#afdfdd17d5049e9f133ace40b2d07d735',1,'ContinueGame1(struct Worm *worm1, struct Worm *worm2, struct Map *map, Renderer render, Window window):&#160;gameMode.c']]],
  ['created',['created',['../struct_map.html#a368c5f76ae2a22edbe18b4d087195a3e',1,'Map']]],
  ['createhighscoresfile',['CreateHighScoresFile',['../high_scores_8c.html#a9207893ef101ead3c6d6336dc909884e',1,'CreateHighScoresFile():&#160;highScores.c'],['../high_scores_8h.html#a9207893ef101ead3c6d6336dc909884e',1,'CreateHighScoresFile():&#160;highScores.c']]],
  ['createmap',['CreateMap',['../map_8c.html#aee8bdbd8ba7388a499295734875b35de',1,'CreateMap(Renderer render, Window window):&#160;map.c'],['../map_8h.html#aee8bdbd8ba7388a499295734875b35de',1,'CreateMap(Renderer render, Window window):&#160;map.c']]],
  ['createworm',['CreateWorm',['../_worm_8c.html#a05771f6dd144eae8c70f9620a302ec87',1,'CreateWorm(Renderer worm_render, Window window, int rotate, int x, int y, int h, int w):&#160;Worm.c'],['../_worm_8h.html#a05771f6dd144eae8c70f9620a302ec87',1,'CreateWorm(Renderer worm_render, Window window, int rotate, int x, int y, int h, int w):&#160;Worm.c']]]
];
