var searchData=
[
  ['coeff',['coeff',['../struct_saved_worm.html#a289789fb674ef8a44ecd4a8c8a6d1fa8',1,'SavedWorm::coeff()'],['../struct_worm.html#a289789fb674ef8a44ecd4a8c8a6d1fa8',1,'Worm::coeff()']]],
  ['created',['created',['../struct_map.html#a368c5f76ae2a22edbe18b4d087195a3e',1,'Map']]]
];
