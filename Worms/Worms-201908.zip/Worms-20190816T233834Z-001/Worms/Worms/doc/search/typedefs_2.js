var searchData=
[
  ['surface',['Surface',['../types_shorter_8h.html#ad9484a459fb29814a84464e4ec06773b',1,'typesShorter.h']]]
];
