var searchData=
[
  ['alfa',['alfa',['../game_8h.html#a78b48c50e33cb672d84d42208f0e38eb',1,'game.h']]]
];
