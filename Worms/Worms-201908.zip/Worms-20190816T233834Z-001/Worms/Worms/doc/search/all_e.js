var searchData=
[
  ['rangeintersect',['RangeIntersect',['../_worm_8h.html#a21a3386f499074b7ba9544cfbfdbaaaa',1,'Worm.h']]],
  ['readhighscores',['ReadHighScores',['../high_scores_8c.html#a5407da418def18baa7e871e10a24fc80',1,'ReadHighScores():&#160;highScores.c'],['../high_scores_8h.html#a5407da418def18baa7e871e10a24fc80',1,'ReadHighScores():&#160;highScores.c']]],
  ['renderer',['Renderer',['../types_shorter_8h.html#afaa0b4196a36103ce28f950eefb341f2',1,'typesShorter.h']]],
  ['reset',['Reset',['../game_mode_8c.html#a7fb7203833ad4262d552d6f99188d66f',1,'Reset(struct Worm worm):&#160;gameMode.c'],['../game_mode_8h.html#a7fb7203833ad4262d552d6f99188d66f',1,'Reset(struct Worm worm):&#160;gameMode.c']]],
  ['resume',['Resume',['../game_8h.html#aa2b3a31620b745eacf4ca48ca56e4683',1,'Resume(struct Worm *worm1, struct Worm *worm2, struct Map *map, Renderer render):&#160;gameMode.c'],['../game_mode_8c.html#aa2b3a31620b745eacf4ca48ca56e4683',1,'Resume(struct Worm *worm1, struct Worm *worm2, struct Map *map, Renderer render):&#160;gameMode.c'],['../game_mode_8h.html#aa2b3a31620b745eacf4ca48ca56e4683',1,'Resume(struct Worm *worm1, struct Worm *worm2, struct Map *map, Renderer render):&#160;gameMode.c']]],
  ['resume_5fbutt',['resume_butt',['../game_8c.html#a644e20345bab8ea3258ffddfa08bf8f9',1,'resume_butt():&#160;game.c'],['../game_mode_8c.html#a644e20345bab8ea3258ffddfa08bf8f9',1,'resume_butt():&#160;gameMode.c'],['../_main_8c.html#a644e20345bab8ea3258ffddfa08bf8f9',1,'resume_butt():&#160;Main.c']]],
  ['rotate',['rotate',['../struct_saved_worm.html#a0b95db0f87fcbe71c3bbda1fa359606f',1,'SavedWorm::rotate()'],['../struct_worm.html#a0b95db0f87fcbe71c3bbda1fa359606f',1,'Worm::rotate()']]]
];
