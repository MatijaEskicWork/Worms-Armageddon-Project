var searchData=
[
  ['rangeintersect',['RangeIntersect',['../_worm_8h.html#a21a3386f499074b7ba9544cfbfdbaaaa',1,'Worm.h']]],
  ['readhighscores',['ReadHighScores',['../high_scores_8c.html#a5407da418def18baa7e871e10a24fc80',1,'ReadHighScores():&#160;highScores.c'],['../high_scores_8h.html#a5407da418def18baa7e871e10a24fc80',1,'ReadHighScores():&#160;highScores.c']]],
  ['reset',['Reset',['../game_mode_8c.html#a7fb7203833ad4262d552d6f99188d66f',1,'Reset(struct Worm worm):&#160;gameMode.c'],['../game_mode_8h.html#a7fb7203833ad4262d552d6f99188d66f',1,'Reset(struct Worm worm):&#160;gameMode.c']]],
  ['resume',['Resume',['../game_8h.html#aa2b3a31620b745eacf4ca48ca56e4683',1,'Resume(struct Worm *worm1, struct Worm *worm2, struct Map *map, Renderer render):&#160;gameMode.c'],['../game_mode_8c.html#aa2b3a31620b745eacf4ca48ca56e4683',1,'Resume(struct Worm *worm1, struct Worm *worm2, struct Map *map, Renderer render):&#160;gameMode.c'],['../game_mode_8h.html#aa2b3a31620b745eacf4ca48ca56e4683',1,'Resume(struct Worm *worm1, struct Worm *worm2, struct Map *map, Renderer render):&#160;gameMode.c']]]
];
