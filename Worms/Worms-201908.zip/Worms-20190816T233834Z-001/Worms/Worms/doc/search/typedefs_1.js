var searchData=
[
  ['renderer',['Renderer',['../types_shorter_8h.html#afaa0b4196a36103ce28f950eefb341f2',1,'typesShorter.h']]]
];
