var searchData=
[
  ['typesshorter_2eh',['typesShorter.h',['../types_shorter_8h.html',1,'']]]
];
