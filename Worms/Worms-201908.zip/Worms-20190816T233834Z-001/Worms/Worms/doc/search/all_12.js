var searchData=
[
  ['vx',['vx',['../struct_saved_missile.html#a2d31cc80a747457c212675a58c68b2b1',1,'SavedMissile::vx()'],['../struct_saved_worm.html#a1dcebb30dc389e2ff55dd6973c56873b',1,'SavedWorm::vx()'],['../struct_missile.html#a2d31cc80a747457c212675a58c68b2b1',1,'Missile::vx()'],['../struct_worm.html#a1dcebb30dc389e2ff55dd6973c56873b',1,'Worm::vx()']]],
  ['vy',['vy',['../struct_saved_missile.html#a42e75115788e629a258d041808d822a0',1,'SavedMissile::vy()'],['../struct_saved_worm.html#a0266e69308ca5226dfa96ac35fc265ba',1,'SavedWorm::vy()'],['../struct_missile.html#a42e75115788e629a258d041808d822a0',1,'Missile::vy()'],['../struct_worm.html#a0266e69308ca5226dfa96ac35fc265ba',1,'Worm::vy()']]]
];
