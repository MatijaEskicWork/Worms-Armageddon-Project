var searchData=
[
  ['encrypt',['Encrypt',['../high_scores_8c.html#a90b11544d2439ae6a7d8dd595772c239',1,'Encrypt(HighScore Player, char *en_name, char *en_score):&#160;highScores.c'],['../high_scores_8h.html#a8c7007d10fb23474240def9670c424c4',1,'Encrypt(HighScore, char *, char *):&#160;highScores.c']]]
];
