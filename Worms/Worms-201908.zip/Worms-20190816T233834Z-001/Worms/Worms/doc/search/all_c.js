var searchData=
[
  ['original',['Original',['../high_scores_8c.html#abc2d21321218271c3f69ad98b3e190e5',1,'Original(char *path):&#160;highScores.c'],['../high_scores_8h.html#ab8ae6af5965b5e542f1342ca350fc978',1,'Original(char *):&#160;highScores.c']]]
];
