var searchData=
[
  ['fileexists',['FileExists',['../high_scores_8c.html#abed98d4c187d0990eea24ba93bcbb542',1,'FileExists(const char *file_name):&#160;highScores.c'],['../high_scores_8h.html#af50924776ba128d4e2372bb464d0de5d',1,'FileExists(const char *):&#160;highScores.c']]],
  ['findangle',['FindAngle',['../_a_i_8c.html#ac083d210d302be5eb8ac382d3f7574c2',1,'FindAngle(int worm1x, int worm1y, int worm2x, int worm2y, int option):&#160;AI.c'],['../_a_i_8h.html#ac083d210d302be5eb8ac382d3f7574c2',1,'FindAngle(int worm1x, int worm1y, int worm2x, int worm2y, int option):&#160;AI.c']]],
  ['firee',['Firee',['../game_8c.html#ad222cc7ef964e3ac463441481aab811b',1,'Firee(struct Map *map, Renderer render, struct Worm worm, struct Worm *wormx):&#160;game.c'],['../game_8h.html#ad222cc7ef964e3ac463441481aab811b',1,'Firee(struct Map *map, Renderer render, struct Worm worm, struct Worm *wormx):&#160;game.c']]]
];
