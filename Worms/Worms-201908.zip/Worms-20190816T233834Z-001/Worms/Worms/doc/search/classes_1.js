var searchData=
[
  ['highscore',['HighScore',['../struct_high_score.html',1,'']]],
  ['highscorelist',['HighScoreList',['../struct_high_score_list.html',1,'']]]
];
