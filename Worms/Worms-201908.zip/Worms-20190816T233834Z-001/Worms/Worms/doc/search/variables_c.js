var searchData=
[
  ['resume_5fbutt',['resume_butt',['../game_8c.html#a644e20345bab8ea3258ffddfa08bf8f9',1,'resume_butt():&#160;game.c'],['../game_mode_8c.html#a644e20345bab8ea3258ffddfa08bf8f9',1,'resume_butt():&#160;gameMode.c'],['../_main_8c.html#a644e20345bab8ea3258ffddfa08bf8f9',1,'resume_butt():&#160;Main.c']]],
  ['rotate',['rotate',['../struct_saved_worm.html#a0b95db0f87fcbe71c3bbda1fa359606f',1,'SavedWorm::rotate()'],['../struct_worm.html#a0b95db0f87fcbe71c3bbda1fa359606f',1,'Worm::rotate()']]]
];
