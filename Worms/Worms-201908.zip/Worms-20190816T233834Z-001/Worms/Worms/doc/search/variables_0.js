var searchData=
[
  ['aim_5frect',['aim_rect',['../struct_saved_worm.html#a31db3007594f81039a2089315dcb9f22',1,'SavedWorm::aim_rect()'],['../struct_worm.html#a31db3007594f81039a2089315dcb9f22',1,'Worm::aim_rect()']]],
  ['aim_5ftex',['aim_tex',['../struct_worm.html#ae9c1b37829d3546807bdd14eb0556963',1,'Worm']]],
  ['angle',['angle',['../struct_saved_missile.html#a79dea7ed146af26ff4a0ba4bf5c83eee',1,'SavedMissile::angle()'],['../struct_missile.html#a79dea7ed146af26ff4a0ba4bf5c83eee',1,'Missile::angle()']]]
];
