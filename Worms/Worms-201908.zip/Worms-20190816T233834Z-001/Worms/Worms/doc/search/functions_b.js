var searchData=
[
  ['savegame',['SaveGame',['../continue_8c.html#a672a03dab89704f2e993eb5bc7302f31',1,'SaveGame(struct Worm *worm1, struct Worm *worm2, struct Map *map):&#160;continue.c'],['../continue_8h.html#a672a03dab89704f2e993eb5bc7302f31',1,'SaveGame(struct Worm *worm1, struct Worm *worm2, struct Map *map):&#160;continue.c']]],
  ['singleplayermode',['SingleplayerMode',['../game_mode_8c.html#a00da50da6b899b1d888d62c707bf1f68',1,'SingleplayerMode(struct Worm *worm_1, struct Worm *worm_2, struct Map map, Renderer render, Window window, int game_mode):&#160;gameMode.c'],['../game_mode_8h.html#a00da50da6b899b1d888d62c707bf1f68',1,'SingleplayerMode(struct Worm *worm_1, struct Worm *worm_2, struct Map map, Renderer render, Window window, int game_mode):&#160;gameMode.c']]]
];
